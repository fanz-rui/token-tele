module.exports = {
  BOT_TOKEN: "YOUR_TOKEN_BOT_API",
  OWNER_ID: ["6142885267"],
};

/*/━━━━━━━━━━━━━━━━━━━━━━  
🔥 XVINCENT 🔥  
━━━━━━━━━━━━━━━━━━━━━━  

🚀 Developer  : RenXiter  
📢 Info       : @RenIsDev  
🛠️ Version    : 5.0  

⚠️ **警告!** ⚠️  
📌 此机器人使用数据库。  
📌 如果您的令牌 **未在数据库中注册**，  
📌 机器人将 **无法运行**！  
📌 请确保您的令牌已注册后再使用本机器人。  

⚠️ **PERINGATAN!** ⚠️  
📌 Bot ini menggunakan database.  
📌 Jika token Anda **tidak terdaftar di database**,  
📌 bot **tidak akan berjalan**!  
📌 Pastikan token Anda sudah terdaftar sebelum menggunakan bot ini.  

━━━━━━━━━━━━━━━━━━━━━━/*/